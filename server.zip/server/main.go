package main

import (
	"context"
	trippb "coolcar/proto/gen/go"
	trip "coolcar/tripservice"
	"fmt"
	"log"
	"net"
	"net/http"

	"github.com/grpc-ecosystem/grpc-gateway/runtime"
	"google.golang.org/grpc"
)

func startGRPCGatway() {
	c := context.Background()          //生成没具体内容的上下文
	c, cancel := context.WithCancel(c) //该方法将具有cancel的能力
	defer cancel()

	//runtime.WithMarshalerOption()将Status: trippb.TripStatus_FINISHED,改为status:3
	mux := runtime.NewServeMux(runtime.WithMarshalerOption(
		runtime.MIMEWildcard, &runtime.JSONPb{
			EnumsAsInts: false, //status
			OrigName:    true,  //命名
		},
	))

	err := trippb.RegisterTripServiceHandlerFromEndpoint(
		c, //通过context去连接, 注册在runtime.NewServeMux()上面
		mux,
		":8081",
		[]grpc.DialOption{grpc.WithInsecure()}, //grpc.WithInsecure()连接方式tcp明文
	)
	if err != nil {
		log.Fatalf("断开连接: %v", err)
	}

	err = http.ListenAndServe(":8080", mux)
	if err != nil {
		log.Fatalf("连接失败: %v", err)
	}
}

//service 端
func main() {
	fmt.Println("监听开始")
	go startGRPCGatway()
	list, err := net.Listen("tcp", ":8081")
	if err != nil {
		log.Fatalf("监听失败: %v", err)
	}
	s := grpc.NewServer() //NewServer 创建一个未注册服务且尚未开始接受请求的 gRPC 服务器。
	trippb.RegisterTripServiceServer(s, &trip.Service{})
	fmt.Println("监听结束")
	fmt.Println(list)
	log.Fatal(s.Serve(list)) //s.Serve()方法不会退出

}
